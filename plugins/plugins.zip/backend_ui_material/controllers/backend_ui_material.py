#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Created with YooLiang Technology (侑良科技).
# Author: Qi-Liang Wen (温啓良）
# Web: http://www.yooliang.com/
# Date: 2015/7/12.

from monkey import Controller, route, route_with, controllers, settings


def add_menu(menus, menu_item, c):
    if menu_item:
        for menu in menu_item:
            if menu["sort"]:
                sort = menu["sort"]
            else:
                sort = 1
            url = ""
            try:
                url = c.uri(menu["uri"])
            except:
                continue
            insert_item = {
                "uri": menu["uri"],
                "url": url,
                "text": menu["text"],
                "sort": sort,
                "level": 1
            }
            if "group" in menu:
                sub_item = insert_item.copy()
                sub_item["level"] = 2
                insert_item["text"] = menu["group"]
                insert_item["url"] = "#"
                is_find = None
                for j in menus:
                    if j["text"] == menu["group"] and j["level"] == 1:
                        is_find = j
                if is_find:
                    if "submenu" in is_find:
                        if is_find["sort"] > sub_item["sort"]:
                            is_find["sort"] = sub_item["sort"]
                        is_find["submenu"].append(sub_item)
                        is_find["submenu"] = sorted(is_find["submenu"], key=lambda k: k['sort'])
                    else:
                        is_find["submenu"] = [sub_item]
                else:
                    insert_item["submenu"] = [sub_item]
                    menus.append(insert_item)
            else:
                menus.append(insert_item)


class BackendUiMaterial(Controller):
    @route_with("/admin/")
    @route_with("/admin")
    def admin_backend(self):
        try:
            admin_user = self.session["administrator_name"]
        except KeyError:
            return self.redirect(self.uri('backend_ui_material:login'))
        if admin_user is None:
            return self.redirect(self.uri('backend_ui_material:login'))
        import datetime
        self.context["now"] = datetime.datetime.now()
        menus = []
        a = self.util.backend_menu()
        try:
            add_menu(menus, a, self)
        except:
            pass
#        for item in controllers:
#            m = item.Meta
#            try:
#                add_menu(menus, m.admin_menu)
#            except:
#                pass
#            try:
#                if self.session["advanced_admin"] is True:
#                    add_menu(menus, m.advanced_menu)
#            except:
#                pass
        menus = sorted(menus, key=lambda k: k['sort'])
        try:
            self.context["backend_title"] = settings.get("application").get("name")
        except:
            self.context["backend_title"] = u"網站後台"
        self.context["controllers"] = controllers
        self.context["menus"] = menus
        self.context["bg_color"] = ""
        self.context["backend_version"] = "0.2.1"

    @route_with("/admin/aa")
    def admin_aa(self):
        self.session["advanced_admin"] = True
        self.session["administrator_name"] = "WOW"
        return self.redirect(self.uri('backend_ui_material:backend'))

    @route_with("/admin/setting")
    def setting(self):
        pass

    @route_with("/admin/login")
    def login(self):
        try:
            self.context["backend_title"] = settings.get("application").get("name")
        except:
            self.context["backend_title"] = u"網站後台"

    @route_with("/admin/login.json")
    def login_json(self):
        self.meta.change_view('json')
        self.context['data'] = {
            'is_login': u'false'
        }
        if self.request.method != "POST":
            return
        s = settings.get("application")
        if s.get("administrator_account") != self.request.params["account"] or \
            s.get("administrator_password") != self.request.params["password"]:
            return
        self.session["administrator_name"] = s.get("administrator_name")
        self.context['data'] = {
            'is_login': 'true'
        }


    @route_with("/admin/logout")
    def logout(self):
        self.session["account"] = None
        self.session["already_login"] = False
        self.session["administrator_name"] = None
        self.meta.change_view('json')
        self.context['data'] = {
            'is_logout': 'true'
        }

